#include "disaster.h"

int main() {
    runDisasterSimulation();
    return 0;
}
