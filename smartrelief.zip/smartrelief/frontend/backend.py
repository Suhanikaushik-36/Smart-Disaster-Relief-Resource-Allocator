# backend.py
def allocate_relief(input_file="input.txt"):
    """
    Reads input.txt and returns a string with relief allocation result
    """
    try:
        with open(input_file, "r") as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        return "Error: input.txt not found!"

    areas = {}
    roads = []

    mode = None
    for line in lines:
        if line.strip() == "AREAS":
            mode = "areas"
            continue
        if line.strip() == "ROADS":
            mode = "roads"
            continue
        if not line.strip():
            continue
        if mode == "areas":
            parts = line.split()
            name = " ".join(parts[:-1])
            severity = int(parts[-1])
            areas[name] = severity
        elif mode == "roads":
            a1, a2, dist = line.split()
            roads.append((a1, a2, int(dist)))

    # Example: sort by severity
    sorted_areas = sorted(areas.items(), key=lambda x: x[1], reverse=True)
    result = "=== Backend Relief Allocation ===\n"
    for i, (area, sev) in enumerate(sorted_areas, start=1):
        result += f"{i}) {area} (Severity: {sev})\n"
    return result

