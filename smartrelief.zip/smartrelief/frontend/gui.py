import tkinter as tk
from tkinter import messagebox
import networkx as nx
import matplotlib.pyplot as plt
from backend import allocate_relief  # Ensure backend.py is in same folder

# ===============================
#   GLOBAL DATA STRUCTURES
# ===============================
areas = {}
roads = []
G = nx.Graph()

# ===============================
#   FUNCTIONS
# ===============================
def add_area():
    """Add an affected area with severity."""
    name = area_entry.get().strip()
    severity = severity_entry.get().strip()
    if not name or not severity:
        messagebox.showwarning("⚠️ Input Error", "Please enter both Area Name and Severity (1–10).")
        return
    try:
        sev = int(severity)
    except:
        messagebox.showerror("Error", "Severity must be a number.")
        return
    areas[name] = sev
    G.add_node(name)
    messagebox.showinfo("✅ Added", f"Area '{name}' added with Severity {sev}.")
    area_entry.delete(0, tk.END)
    severity_entry.delete(0, tk.END)

def add_road():
    """Add a road (edge) between two areas (case-insensitive)."""
    from_area = from_entry.get().strip()
    to_area = to_entry.get().strip()
    distance = distance_entry.get().strip()

    # Match areas case-insensitive
    from_area_corrected = None
    to_area_corrected = None
    for area_name in areas.keys():
        if from_area.lower() == area_name.lower():
            from_area_corrected = area_name
        if to_area.lower() == area_name.lower():
            to_area_corrected = area_name

    if not from_area_corrected or not to_area_corrected:
        messagebox.showerror("❌ Error", "Add both areas before creating a road (check spelling).")
        return

    if not distance:
        messagebox.showwarning("⚠️ Input Error", "Distance cannot be empty.")
        return

    try:
        dist = int(distance)
    except:
        messagebox.showerror("Error", "Distance must be a number.")
        return

    roads.append((from_area_corrected, to_area_corrected, dist))
    G.add_edge(from_area_corrected, to_area_corrected, weight=dist)
    messagebox.showinfo("✅ Road Added", f"Road added: {from_area_corrected} ↔ {to_area_corrected} ({dist} km)")

    from_entry.delete(0, tk.END)
    to_entry.delete(0, tk.END)
    distance_entry.delete(0, tk.END)

def save_input_file():
    """Save all areas and roads into input.txt (backend will use later)."""
    try:
        with open("input.txt", "w") as f:
            f.write("AREAS\n")
            for name, sev in areas.items():
                f.write(f"{name} {sev}\n")
            f.write("ROADS\n")
            for a1, a2, d in roads:
                f.write(f"{a1} {a2} {d}\n")
        messagebox.showinfo("💾 Saved", "All data saved to input.txt successfully!")
    except Exception as e:
        messagebox.showerror("❌ Save Error", str(e))

def run_simulation():
    """Call backend function and display output."""
    if not areas or not roads:
        messagebox.showwarning("⚠️ Missing Data", "Please add some areas and roads first!")
        return

    result_text.delete("1.0", tk.END)
    result = allocate_relief("input.txt")
    result_text.insert(tk.END, result)
    draw_graph()

def draw_graph():
    """Visualize the graph of areas and roads."""
    plt.clf()
    pos = nx.spring_layout(G)
    colors = []
    for node in G.nodes():
        sev = areas.get(node, 0)
        if sev >= 8:
            colors.append("red")
        elif sev >= 5:
            colors.append("yellow")
        else:
            colors.append("lightgreen")

    nx.draw(G, pos, with_labels=True, node_color=colors, node_size=1000, font_size=10)
    labels = nx.get_edge_attributes(G, "weight")
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)
    plt.title("Disaster Relief Route Map")
    plt.show()

# ===============================
#   GUI DESIGN
# ===============================
root = tk.Tk()
root.title("🚑 Smart Disaster Relief Resource Allocator")
root.geometry("900x650")
root.config(bg="#f0f4f7")

# --- Header ---
tk.Label(root, text="Smart Disaster Relief Resource Allocator", font=("Arial", 18, "bold"), bg="#f0f4f7").pack(pady=10)

# --- Area Input ---
area_frame = tk.Frame(root, bg="#f0f4f7")
area_frame.pack(pady=5)
tk.Label(area_frame, text="Area Name:", bg="#f0f4f7").grid(row=0, column=0, padx=5)
area_entry = tk.Entry(area_frame)
area_entry.grid(row=0, column=1, padx=5)
tk.Label(area_frame, text="Severity (1–10):", bg="#f0f4f7").grid(row=0, column=2, padx=5)
severity_entry = tk.Entry(area_frame)
severity_entry.grid(row=0, column=3, padx=5)
tk.Button(area_frame, text="Add Area", bg="#007bff", fg="white", command=add_area).grid(row=0, column=4, padx=10)

# --- Road Input ---
road_frame = tk.Frame(root, bg="#f0f4f7")
road_frame.pack(pady=5)
tk.Label(road_frame, text="From:", bg="#f0f4f7").grid(row=0, column=0, padx=5)
from_entry = tk.Entry(road_frame)
from_entry.grid(row=0, column=1, padx=5)
tk.Label(road_frame, text="To:", bg="#f0f4f7").grid(row=0, column=2, padx=5)
to_entry = tk.Entry(road_frame)
to_entry.grid(row=0, column=3, padx=5)
tk.Label(road_frame, text="Distance:", bg="#f0f4f7").grid(row=0, column=4, padx=5)
distance_entry = tk.Entry(road_frame)
distance_entry.grid(row=0, column=5, padx=5)
tk.Button(road_frame, text="Add Road", bg="#28a745", fg="white", command=add_road).grid(row=0, column=6, padx=10)

# --- Buttons ---
btn_frame = tk.Frame(root, bg="#f0f4f7")
btn_frame.pack(pady=10)
tk.Button(btn_frame, text="💾 Save Input (input.txt)", bg="#6c757d", fg="white", command=save_input_file).grid(row=0, column=0, padx=10)
tk.Button(btn_frame, text="▶ Run Simulation", bg="#ff6f00", fg="white", font=("Arial", 11, "bold"), command=run_simulation).grid(row=0, column=1, padx=10)

# --- Output Box ---
result_text = tk.Text(root, height=14, width=100)
result_text.pack(pady=10)

tk.Label(root, text="Note: Data will be saved as input.txt (backend will use it later).", bg="#f0f4f7", fg="gray").pack(pady=5)

root.mainloop()
